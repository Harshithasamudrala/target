package com.niit.shoppingcart.dao;

import org.hibernate.SessionFactory;

public class CategoryDAOImpl implements CategoryDAO {

	public CategoryDAOImpl(SessionFactory sf) {
		// TODO Auto-generated constructor stub
	}

}
