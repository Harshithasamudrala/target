package com.niit.shoppingcart.model;

public class Category {

}
