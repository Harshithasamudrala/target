package com.niit.shoppingcart.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.niit.shoppingcart.beans.Product;

@Repository
public class ProductDAO {

	public List<Product> getAllProducts() {

		List<Product> list = new ArrayList<Product>();
		Product p1 = new Product();
		p1.setId(1);
		p1.setName("Nike-Mercurial");
		p1.setPrice(5497);
		
		list.add(p1);

		Product p2 = new Product();
		p2.setId(2);
		p2.setName("Nike-HyperVenom");
		p2.setPrice(8914);
		
		list.add(p2);
		
		Product p3 = new Product();
		p3.setId(3);
		p3.setName("Adidas-F50");
		p3.setPrice(14532);
		
		list.add(p3);
		return list;

	}
}
