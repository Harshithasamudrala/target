package com.niit.shoppingcart.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcart.beans.Product;
import com.niit.shoppingcart.dao.ProductDAO;

@Controller
public class ProductController {

	@Autowired
	ProductDAO proDAO;

	@RequestMapping("/getAllProducts")
	public ModelAndView getAllProducts() {

		System.out.println("get all Products");

		List<Product> productlist = proDAO.getAllProducts();

		ModelAndView mv = new ModelAndView("/products");
		mv.addObject("productlist", productlist);

		return mv;
	}

	@RequestMapping("/updateSuppliers")
	public ModelAndView update() {

		return null;
	}

}
