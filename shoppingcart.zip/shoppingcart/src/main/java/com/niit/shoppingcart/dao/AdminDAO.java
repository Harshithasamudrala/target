package com.niit.shoppingcart.dao;

import org.springframework.stereotype.Repository;

@Repository
public class AdminDAO {

	public boolean isValidUser(String Username, String password) {
		System.out.println("**************AdminDao invoked***");
		if (Username.equals("Mahesh") && password.equals("123")) {
			return true;

		} else {
			return false;
		}
	}
}
