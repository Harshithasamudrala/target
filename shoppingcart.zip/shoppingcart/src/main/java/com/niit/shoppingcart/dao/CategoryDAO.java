package com.niit.shoppingcart.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.niit.shoppingcart.beans.Category;

@Repository
public class CategoryDAO {

	public List<Category> getAllCategories() {

		List<Category> list = new ArrayList<Category>();
		Category c1 = new Category();
		c1.setId(1);
		c1.setName("Nike");
		c1.setDescription("this is shoe category");

		list.add(c1);

		Category c2 = new Category();

		c2.setId(2);
		c2.setName("Puma");
		c2.setDescription("this is gloves category");

		list.add(c2);

		Category c3 = new Category();

		c3.setId(3);
		c3.setName("Reebok");
		c3.setDescription("this is shin gaurds category");

		list.add(c3);
		return list;

	}
}
