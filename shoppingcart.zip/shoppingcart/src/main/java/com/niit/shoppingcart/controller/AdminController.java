package com.niit.shoppingcart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcart.dao.AdminDAO;

@Controller
public class AdminController {

	@Autowired
	AdminDAO adminDao;

	@RequestMapping("/isValidAdmin")
	public ModelAndView showMessage(@RequestParam(value = "username") String Username,
			@RequestParam(value = "password") String password) {

		System.out.println("*****AdminController invoked*****");
		String message = null;
		ModelAndView mv = null;
		if (adminDao.isValidUser(Username, password)) {

			message = "Valid credentials..!";
			mv = new ModelAndView("AdminHome");
			mv.addObject("message", message);
			mv.addObject("name", Username);

		} else {

			message = "InValid credentials..!";
			mv = new ModelAndView("login");
			mv.addObject("message", message);
			mv.addObject("name", Username);

		}
		return mv;
	}
}
