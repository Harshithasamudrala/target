package com.niit.shoppingcart.controller;

import java.util.List;
import java.util.function.Supplier;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcart.beans.Suppliers;
import com.niit.shoppingcart.dao.SuppliersDAO;

@Controller
public class SuppliersController {

	@Autowired
	SuppliersDAO supDAO;

	@RequestMapping("/getAllSuppliers")
	public ModelAndView getAllSuppliers() {

		System.out.println("get all suppliers");

		List<Suppliers> supplylist = supDAO.getAllSuppliers();

		ModelAndView mv = new ModelAndView("/category");
		mv.addObject("supplylist", supplylist);

		return mv;
	}

	@RequestMapping("/updateSuppliers")
	public ModelAndView update() {

		return null;
	}

}
