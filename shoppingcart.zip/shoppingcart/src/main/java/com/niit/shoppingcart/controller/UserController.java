package com.niit.shoppingcart.controller;

public class UserController {

}
