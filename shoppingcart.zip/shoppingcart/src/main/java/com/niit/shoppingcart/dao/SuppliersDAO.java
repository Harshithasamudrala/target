package com.niit.shoppingcart.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.niit.shoppingcart.beans.Suppliers;

@Repository
public class SuppliersDAO {

	public List<Suppliers> getAllSuppliers() {

		List<Suppliers> list = new ArrayList<Suppliers>();
		Suppliers s1 = new Suppliers();
		s1.setId(1);
		s1.setName("Mahesh");
		s1.setPlace("Banglore");
		s1.setSupply("outdoor game accessories");

		list.add(s1);

		Suppliers s2 = new Suppliers();
		s2.setId(2);
		s2.setName("Ershad");
		s2.setPlace("Mumbai");
		s2.setSupply("indoor game accessories");
		list.add(s2);

		Suppliers s3 = new Suppliers();
		s3.setId(3);
		s3.setName("Vivek");
		s3.setPlace("Chennai");
		s3.setSupply("Clothing");
		list.add(s3);
		return list;

	}
}
