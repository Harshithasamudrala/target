package com.niit.shoppingcart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcart.beans.Category;
import com.niit.shoppingcart.dao.CategoryDAO;

@Controller
public class CategoryController {

	@Autowired
	CategoryDAO catDAO;

	@RequestMapping("/getAllCategories")
	public ModelAndView getAllCategories() {

		System.out.println("get all categories");

		List<Category> categorylist = catDAO.getAllCategories();

		ModelAndView mv = new ModelAndView("/category");
		mv.addObject("categorylist", categorylist);

		return mv;
	}

	@RequestMapping("/updateCategories")
	public ModelAndView update() {

		return null;
	}

}
