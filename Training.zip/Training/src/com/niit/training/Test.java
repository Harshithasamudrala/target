package com.niit.training;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.niit.training.bean.Account;
import com.niit.training.bean.Customer;

public class Test {
	public static void main(String[] args) {
		// customer created
		Customer c1 = new Customer();
		c1.setId(101);
		c1.setName("manu");
		c1.setPassword("kk");
		c1.setPermanantaddress("address");
		c1.setShippingaddress("sadress");
		// create first account
		Account ac1 = new Account();
		ac1.setAccountid(101);
		ac1.setAcname("harshi");

		// List
		List accounts = new ArrayList();

		// Sec acc
		Account ac2 = new Account();
		ac2.setAccountid(102);
		ac2.setAcname("harshi2");
		accounts.add(ac1);

		accounts.add(ac2);

		c1.setMyAccounts(accounts);

		System.out.println(c1.getId());
		System.out.println(c1.getName());
		System.out.println(c1.getPassword());
		System.out.println(c1.getPermanantaddress());
		System.out.println(c1.getShippingaddress());
		List allmyaccounts = c1.getMyAccounts();

		Iterator it = allmyaccounts.iterator();

		while (it.hasNext()) {

			System.out.println(it.next());
		}

	}

}
