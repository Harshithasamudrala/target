package com.niit.training.bean;

import java.util.ArrayList;
import java.util.List;

public class Customer extends User {

	private String shippingaddress;
	private String permanantaddress;
	private List myAccounts=new ArrayList();
	

	public List getMyAccounts() {
		return myAccounts;
	}
	public void setMyAccounts(List myAccounts) {
		this.myAccounts = myAccounts;
	}
	public String getShippingaddress() {
		return shippingaddress;
	}
	public void setShippingaddress(String shippingaddress) {
		this.shippingaddress = shippingaddress;
	}
	public String getPermanantaddress() {
		return permanantaddress;
	}
	public void setPermanantaddress(String permanantaddress) {
		this.permanantaddress = permanantaddress;
	}
	

}
