package com.niit.training.bean;

public class Account extends User{
	private int accountid;
	private String acname;

	// getters and setters
	public int getAccountid() {
		return accountid;
	}

	public void setAccountid(int accountid) {
		this.accountid = accountid;
	}

	public String getAcname() {
		return acname;
	}

	public void setAcname(String acname) {
		this.acname = acname;
	}

	/*//@Override
	//public String toString() {
		//return "Account [accountid=" + accountid + ", acname=" + acname + "]";
	}*/

}
