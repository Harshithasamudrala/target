package com.niit.shopping.dao;


public class UserDAO {



public Boolean isValidCredentials(String userid,String password)
{
	if(userid.equals("harshitha")&&password.equals("harshitha"))
	{
		return true;
		}
	return false;
}
}